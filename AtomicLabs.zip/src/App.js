import React, { Component } from 'react';
import Formulario from './componentes/Formulario';
import Formulario2 from './componentes/Formulario2';
import Formulario3 from './componentes/Formulario3';
import './App.css';
import PiePag from './componentes/PiePag';
import Prin from './componentes/Prin';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      first: true,
      second: false,
      three: false,
      four: false
    };

    this.showComponent = this.showComponent.bind(this);
  }

  showComponent(e,name) {
    e.preventDefault();
    if (name===0){
      this.setState({ first: true,second: false,three:false,four:false });
    }
    if (name===1){
      this.setState({ first: false,second: true ,three:false,four:false});
    }
    if (name===2){
      this.setState({ first: false,second: false ,three:true,four:false});
    }
    if (name===3){
      this.setState({ first: false,second: false ,three:false,four:true});
    }
    
      
   
  }
  state = {
    porcentaje: 0.0
  }

  render() {
    const { first, second, three, four } = this.state;
    return (
      <div>
        {first && (

          <Prin muestra={this.showComponent}/>

        
        )}
        {second && (
        
          <div ><Formulario muestra={this.showComponent}/></div>

        
        )}
        {three && (
        
        <div ><Formulario2 muestra={this.showComponent}/></div>

      
      )}
      {four && (
        
        <div ><Formulario3 muestra={this.showComponent}/></div>

      
      )}
        <div className="PiePagina" ><PiePag /></div>
      </div>
    );
  }
}

export default App;