import React, { Component } from 'react';
import '../App.css';
import n1 from '../Imagenes/Group 4014@2x.png';
import ProgressBar from '../componentes/ProgressBar';
import logoAl from '../Imagenes/Group 4033.png';
import PropTypes from 'prop-types';

class Formulario extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };        
      }
	    render(){
	        return (
	            <form><table>
                <div className="table">
                <tr >
                    <td>
                    </td>
                    <td >
                        <ProgressBar porcentaje={16}/>
                    </td>
                </tr><td></td>
                    <td><td>
                        <img src={n1} className="App-nums" alt="n1" />&nbsp;&nbsp;&nbsp;
                        </td><td>
                        <div className="col" ></div>
                            <h3><b>TE QUEREMOS</b> <b className="text-danger text-center">CONOCER</b></h3>
                            <br></br>
                            <h5 >Queremos saber que eres tù, por favor ingresa los siguientes datos:</h5>
                            <br></br>
                            </td><td></td><td></td><td></td>
                            <div className="form-group col-md-8">
                                <h6 >Nombre(s):</h6>
                                <input type="text" className="form-control
                                from-control-lg" placeholder="Nombre(s)"/>
                            </div>
                            <div className="col-md-8">
                                <h6 >Apellidos:</h6>
                                <input type="text" className="form-control
                                from-control-lg" placeholder="Apellidos"/>
                            </div>
                            <div className="form-group col-md-6"><br></br>
                                <button className="btn-lg
                                btn-danger btn-block" onClick={e=>this.props.muestra(e,2)} >Siguiente</button>
                            </div> 
                        
                    </td>
                    <td>
                        <img src={logoAl} className="App-logo2" alt="logo2" />
                    </td>
                </div>
                </table>
                </form>
            );
        }
    
    }

Formulario.propTypes={
    muestra: PropTypes.func
}
export default Formulario;
