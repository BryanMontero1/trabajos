import React, { Component } from 'react';
import '../App.css';
import n1 from '../Imagenes/Group 4014@2x.png';
import ProgressBar from './ProgressBar';
import logoAl from '../Imagenes/Group 4038.png';
import App from '../App';
import PropTypes from 'prop-types';

class Formulario extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    
        
      }
	    render(){
	        return (
	            <form><table>
                <div className="table">
                <tr >
                    <td>
                    </td>
                    <td colSpan={2}>
                        <ProgressBar porcentaje={69}/>
                    </td>
                </tr><td></td>
                    <td className=''><td>
                        <img src={n1} className="App-nums" alt="n1" />&nbsp;&nbsp;&nbsp;
                        </td><td>
                            <h2><b>TERMINOS Y</b> <b className="text-danger text-center">CONDICIONES</b></h2>
                            </td><td></td><td></td>
                            <br></br><br></br><h6 >&nbsp;&nbsp;&nbsp;<u>consulta Terminos y Condiciones:</u></h6><br></br>
                                <div className="form-check">
                                <input classNAme="form-check-input" type="checkbox" id="flexCheckChecked"/>&nbsp;&nbsp;&nbsp;
                                <label className="form-check-label" for="checked">
                                Acepto los Tèrminos y Condiciones
                                </label>
                                </div>
                            <div className="form-group col-md-6"><br></br>
                                <button className="btn-lg
                                btn-danger btn-block" onClick={e=>this.props.muestra(e,1)} >Siguiente</button>
                            </div> 
                        
                    </td>
                    <td>
                        <img src={logoAl} className="App-logo2" alt="logo2" />
                    </td>
                </div>
                </table>
                </form>
            );
        }
    
    }

Formulario.propTypes={
    muestra: PropTypes.func
}
export default Formulario;
