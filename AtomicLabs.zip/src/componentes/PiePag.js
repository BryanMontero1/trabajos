import React from "react";
import twitter from '../Imagenes/twitter.png';
import ins from '../Imagenes/linkedin.png';


function PiePag(props){
    return (
        <div >
            <br></br><br></br>
                <div className="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div className="container-fluid">
                        <div className="formul" >
                          <h6  >©2020 AtomicLabs. todos los derechos reservados. </h6>  
                        </div>
                        <div className="col" >
                          </div>
                        <div className="formul" >
                        <h6>Aviso de privacidad</h6>&nbsp;&nbsp;&nbsp;&nbsp;  </div>
                        <div className="col" >
                        <img src={ins} className="App-nums-min2" alt="ins" />&nbsp;&nbsp;&nbsp;&nbsp;  </div>
                        <div className="col" >
                          <img src={twitter} className="App-nums-min2" alt="twitter" />
                        </div>
                    </div>
                </div>
            </div>
);
}

export default PiePag;