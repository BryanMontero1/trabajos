import React, { Component } from 'react';
import '../App.css';
import logoAl from '../Imagenes/Group 4032.png';
import PropTypes from 'prop-types';

class Prin extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    
        
      }
	    render(){
	        return (
	            <form>
                    <table><tr><td className="wt"><br ></br><br></br><br></br>
                        <div className="text-center"> <img src={logoAl} className="App-logo" alt="logo2" /></div>
                            </td><td ><h1><b>DESARROLLA TODO</b> <br></br>
                            <b className="text-danger text-center">TU POTENCIAL</b><br></br>
                            <b>DENTRO DEL EQUIPO</b> <br></br>
                            <b className="text-danger text-center">ATOMIC</b><b>LABS</b></h1><br></br>
                        <div className="col-md-8">
                                <button className="btn-lg btn-light btn-block" 
                                onClick={e=>this.props.muestra(e,1)} value={1} >!Quiero ser parte¡</button>
                        </div></td>
                        </tr>
                    </table><br></br><br></br><br></br>
                </form>
            );
        }
    }

    Prin.propTypes={
        muestra: PropTypes.func
    }

export default Prin;