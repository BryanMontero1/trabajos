import React from "react";
import '../App.css';
import n1t from '../Imagenes/Group 4014.png';
import n2t from '../Imagenes/Group 4023.png';
import n3t from '../Imagenes/Group 4024.png';
import n4t from '../Imagenes/Group 4025.png';
import n1f from '../Imagenes/Group 1.png';
import n2f from '../Imagenes/Group 4019.png';
import n3f from '../Imagenes/Group 4017.png';
import n4f from '../Imagenes/Group 4018.png';

function ProgressBar(props){
    return (
        <div >
            <br></br><br></br>
            <div className="row" >
                <div className="col" ></div>
                <div className="col" >
                    <img src={ props.porcentaje <=16 ? n1t: n1f} className="App-nums-min" alt="n1" />&nbsp;&nbsp;&nbsp;
                </div>
                <div className="col" ></div>
                <div className="col" >
                    <img src={props.porcentaje ===42 ? n2t: n2f} className="App-nums-min" alt="n2" />
                </div><div className="col" ></div>
                <div className="col" >
                    <img src={props.porcentaje ===69 ? n3t: n3f} className="App-nums-min" alt="n3" />
            </div><div className="col" ></div>
            <div className="col" >
            <img src={props.porcentaje ===100 ? n4t: n4f} className="App-nums-min" alt="n4" />
            </div></div>
            <br></br>
            <div className="progress">
                <div className="progress-bar progress-bar-striped bg-danger progress-bar-animated"
                role="progressbar"
                style={{width: props.porcentaje ? props.porcentaje +"%": "100%"}}>
                </div>
            </div>
        </div>
    );
}


export default ProgressBar;